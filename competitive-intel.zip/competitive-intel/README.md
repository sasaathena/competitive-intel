# 競品情報自動收集系統

每日自動收集 EIP、ERP、CRM、PMS 競品情報，部署在 GitHub Pages 上可直接瀏覽。

## 專案結構

```
competitive-intel/
├── .github/
│   └── workflows/
│       └── daily-collect.yml   # GitHub Actions 排程（每日 09:00 台灣時間）
├── scraper/
│   ├── collect.py              # Python 爬蟲主程式
│   └── requirements.txt        # Python 套件
├── data/
│   ├── articles.json           # 爬蟲輸出（自動更新）
│   └── seen_ids.json           # 去重記錄（自動更新）
└── docs/
    └── index.html              # 前端 Dashboard（GitHub Pages 入口）
```

## 快速開始

### 1. Fork 並啟用 GitHub Pages

1. Fork 本 repo 到你的帳號
2. **Settings → Pages → Source** 選 `Deploy from branch`
3. Branch 選 `main`，資料夾選 `/docs`
4. 儲存後，你的 Dashboard 就在 `https://<你的帳號>.github.io/<repo名>`

### 2. 啟用 Actions 寫入權限

**Settings → Actions → General → Workflow permissions**  
→ 選 **Read and write permissions** → Save

### 3. 手動觸發第一次收集

**Actions → 每日競品情報收集 → Run workflow**

### 4. 等待每日自動執行

GitHub Actions 排程設定為每天 **UTC 01:00（台灣時間 09:00）** 自動執行。

---

## 本地開發

```bash
# 安裝相依套件
pip install -r scraper/requirements.txt

# 執行爬蟲（在 repo 根目錄執行）
python scraper/collect.py

# 啟動本地預覽
cd docs && python -m http.server 8080
# 開啟 http://localhost:8080
```

---

## 自訂關鍵字

編輯 `scraper/collect.py` 的 `SYSTEM_KEYWORDS` 和 `TYPE_KEYWORDS`：

```python
SYSTEM_KEYWORDS = {
    "ERP": ["erp", "sap", "oracle erp", ...],  # 加入你關注的競品名稱
    "CRM": ["crm", "salesforce", ...],
    ...
}
```

---

## 新增資料來源

在 `RSS_FEEDS` 中加入任何 RSS URL：

```python
RSS_FEEDS = [
    {"url": "https://你想監控的網站/feed", "source": "顯示名稱"},
    ...
]
```

---

## 資料格式（data/articles.json）

```json
{
  "stats": {
    "last_updated": "2026-06-04T09:00:00+00:00",
    "total": 284,
    "new_today": 12,
    "by_system": {"CRM": 80, "ERP": 70, "PMS": 90, "EIP": 44},
    "by_type":   {"UIUX": 100, "Dashboard": 60, "功能分析": 90, "競品新聞": 34},
    "by_channel": {"rss": 150, "reddit": 60, ...}
  },
  "articles": [
    {
      "id": "a001",
      "title": "文章標題",
      "url": "https://...",
      "source": "來源名稱",
      "summary": "摘要...",
      "systems": ["CRM"],
      "types": ["UIUX"],
      "date": "2026-06-04T06:00:00+00:00",
      "channel": "rss",
      "score": 0,
      "comments": 0
    }
  ]
}
```
